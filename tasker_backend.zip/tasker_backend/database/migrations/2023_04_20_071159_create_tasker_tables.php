<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        //1. creation of the users table
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('email')->unique();
            $table->string('password');
            $table->timestamps();
        });

        //2. creation of the status table
        Schema::create('status', function (Blueprint $table) {
            $table->id();
            $table->string('post_title', 100);
            $table->text('post_body');
            $table->timestamps();
        });

        //3. creation of the tasks table
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->string('post_title', 100);
            $table->text('post_body');

            $table->bigInteger('status_id', false, true)->unsigned()->index();
            $table->foreign('status_id')
                  ->references('id')
                  ->on('status')
                  ->onUpdate('cascade')
                  ->onDelete('cascade');

            $table->timestamps();
        });

        //4. Creation of the user tasks table
        Schema::create('user_tasks', function (Blueprint $table) {
            $table->id();

            $table->bigInteger('user_id', false, true)->unsigned()->index();
            $table->foreign('user_id')
                  ->references('id')
                  ->on('users')
                  ->onUpdate('cascade')
                  ->onDelete('cascade');


            $table->bigInteger('tasks_id', false, true)->unsigned()->index();
            $table->foreign('tasks_id')
                  ->references('id')
                  ->on('tasks')
                  ->onUpdate('cascade')
                  ->onDelete('cascade');

            $table->text('comment_title');
            $table->text('comment_body');

            $table->bigInteger('status_id', false, true)->unsigned()->index();
            $table->foreign('status_id')
                  ->references('id')
                  ->on('status')
                  ->onUpdate('cascade')
                  ->onDelete('cascade');

            $table->timestamps();
      });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('status');
        Schema::dropIfExists('tasks');
        Schema::dropIfExists('user_tasks');
    }
};